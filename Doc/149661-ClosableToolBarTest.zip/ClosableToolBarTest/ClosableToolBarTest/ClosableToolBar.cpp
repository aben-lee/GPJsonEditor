#include "ClosableToolBar.h"

#include <QAction>
#include <QToolButton>
#include <QVBoxLayout>

namespace
{

std::string CloseToolButtonStyleSheet=  
   "QToolButton:hover {\
      background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0.517045 rgba(251, 182, 170, 255), stop:0.522727 rgba(210, 35, 2, 255), stop:1 rgba(211, 148, 78, 255));\
      border: 1px solid gb(67, 20, 34);\
      border-radius: 2px;\
   }\
   QToolButton {\
      background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0.494318 rgba(233, 169, 156, 255), stop:0.505682 rgba(184, 67, 44, 255), stop:1 rgba(211, 127, 111, 255));\
      border-style: outset;\
      border-width: 1px;\
      border-radius: 2px;\
      font-size: 8px;\
      font-weight: bold;\
      border-color: rgb(67, 20, 34);\
      color: #FFFFFF;\
   }";

}


ClosableToolBar::~ClosableToolBar()
{
}

ClosableToolBar::ClosableToolBar(QWidget *parent)
   : QToolBar(parent)
{
   createCloseButton();
}

void ClosableToolBar::showEvent(QShowEvent *event)
{
   if (!isFloatable()) {
      QToolBar::showEvent(event);
      return;
   }

   if (isFloating()) {
      //to show always at end
      this->removeAction(closeAction);
      this->addAction(closeAction);

      closeAction->setVisible(true);
   } else
      closeAction->setVisible(false);

   QToolBar::showEvent(event);
}

void ClosableToolBar::createCloseButton() 
{
   QVBoxLayout *closeButtonLayout= new QVBoxLayout();
   QMargins margins;
   margins.setLeft(5);
   closeButtonLayout->setContentsMargins(margins);
   closeButtonLayout->setSpacing(0);

   closeButton= new QToolButton();
   closeButton->setText("X");
   closeButton->setStyleSheet(QString::fromStdString(CloseToolButtonStyleSheet));
   closeButton->setFixedSize(12,12);

   if (!connect(closeButton, SIGNAL(clicked()), this, SLOT(hide()))) {
#ifdef _DEBUG
      throw std::runtime_error("Close button - connection failed");
#endif
   }

   closeButtonLayout->addWidget(closeButton);
   closeButtonLayout->addItem(new QSpacerItem(13, 17, QSizePolicy::Minimum, QSizePolicy::Expanding));

   QWidget *closeButtonWidget= new QWidget();
   closeButtonWidget->setLayout(closeButtonLayout);
   closeAction= this->addWidget(closeButtonWidget);
   closeAction->setVisible(false);
}

