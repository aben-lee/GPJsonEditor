#include "ClosableToolBarTest.h"

#include "ClosableToolBar.h"


ClosableToolBarTest::ClosableToolBarTest(QWidget *parent, Qt::WFlags flags)
    : QMainWindow(parent, flags)
{
   ui.setupUi(this);
   
   createToolbar(4,true);
   createToolbar(2,true);
   createToolbar(3,true);
   createToolbar(5,false);
   createToolbar(8,false);
}

ClosableToolBarTest::~ClosableToolBarTest()
{

}

void ClosableToolBarTest::createToolbar( int actionsCount, bool floatable )
{
   ClosableToolBar *tb = new ClosableToolBar(); 
   for (int i= 0; i < actionsCount; i++)
   { 
      QString str(":/ClosableToolBarTest/m");
      str.append(QString("%1").arg(i));

      tb->addAction(QIcon(str),"A");
   }

   tb->setFloatable(floatable);
   addToolBar(tb); 
}

