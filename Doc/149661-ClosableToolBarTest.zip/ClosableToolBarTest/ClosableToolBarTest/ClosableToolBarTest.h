#ifndef CLOSABLETOOLBARTEST_H
#define CLOSABLETOOLBARTEST_H

#include <QtGui/QMainWindow>
#include "ui_ClosableToolBarTest.h"

class ClosableToolBarTest : public QMainWindow
{
    Q_OBJECT

public:
    ~ClosableToolBarTest();
    ClosableToolBarTest(QWidget *parent = 0, Qt::WFlags flags = 0);

private:
    Ui::ClosableToolBarTestClass ui;

    void createToolbar( int quantidadeActions, bool floating );

};

#endif // CLOSABLETOOLBARTEST_H
