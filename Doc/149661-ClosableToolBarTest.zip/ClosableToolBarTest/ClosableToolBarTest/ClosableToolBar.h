#pragma once
#ifndef CLOSABLETOOLBAR_H
#define CLOSABLETOOLBAR_H

#include <QToolBar>

QT_BEGIN_NAMESPACE
class QAction;
class QToolButton;
QT_END_NAMESPACE


class ClosableToolBar : public QToolBar
{

public:
	virtual ~ClosableToolBar();
	ClosableToolBar(QWidget *parent= 0);
   
private:
   void createCloseButton();
   void showEvent(QShowEvent *event);

private:
   QAction *closeAction;
   QToolButton *closeButton;

};

#endif //CLOSABLETOOLBAR_H
