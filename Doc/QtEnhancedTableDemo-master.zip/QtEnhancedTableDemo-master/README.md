# QtEnhancedTableDemo
自定义Qt TableView子类，添加更多实用特性  
1. 列数据过滤功能  
2. 表头支持自动换行
3. 支持在表格中显示checkbox和html数据，支持html中超链接的点击和悬浮信号
